package com.example.desafio2santandercoders

class MainAdapter(
    private val restauranteList: List<Restaurante>,
    private val onItemClicked: (Int) -> Unit
) : Recycl