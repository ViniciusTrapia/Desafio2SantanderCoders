package com.example.desafio2santandercoders

import android.content.Intent
import android.os.Bundle
import android.os.PersistableBundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity3 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.tste_item)

        val restaurantes = mutableListOf<Restaurante>()

        findViewById<RecyclerView>(R.id.rvRestaurante).apply {
            layoutManager = LinearLayoutManager(this@MainActivity3)
            adapter = MainAdapter(users) { position ->
                val intent = Intent(this@HomeActivity, UserPaymentActivity::class.java)
                intent.putExtra(KEY_INTENT_USER, users[position])
                startActivity(intent)
            }
        }







    }
}